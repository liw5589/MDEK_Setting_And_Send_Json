import argparse
import datetime
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
import matplotlib
import matplotlib.pyplot as plt
import threading, requests, time
import numpy as np
import os


rf_db = {}


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()

        sep = re.split('/|\?', self.path)

        if len(sep) == 3:
            params = sep[-1]
            param_dict = self.gen_param(params)

            # get id and distance
            id = param_dict['id']
            d = param_dict['d']
            now = datetime.datetime.now().strftime('%m%d_%H%M%S.%f')[:-3]

            # save to rf_db
            if id in rf_db:
                rf_db[id].append((d, now))
            else:
                rf_db[id] = [(d, now)]

            # print(rf_db)

            self.wfile.write(b'OK')
        else:
            self.wfile.write(b'Hello!')

    def gen_param(self, params):
        paramDic = {}
        for i in params.split('&'):
            if i.find('=') is -1:
                continue
            key, val = i.split('=')
            paramDic[key] = val
        return paramDic


def run(server_class=HTTPServer, handler_class=SimpleHTTPRequestHandler, addr="localhost", port=8000):
    server_address = (addr, port)
    httpd = server_class(server_address, handler_class)

    print("Starting httpd server on {}:{}".format(addr, port))
    httpd.serve_forever()


def visualization(rf_data):
    while True:
        os.system('clear')
        if rf_data:
            data_list = rf_data['123']
            num = len(data_list)
            if num > 1:
                W = np.array(data_list, dtype=np.float64)
                W = W[:, 0]
                X = np.arange(W.min(), W.max(), 0.1)
                hist = plt.hist(W, X, rwidth=0.8, color='red', alpha=0.5)[0]
                avg = np.average(W)
                most_called = X[hist.argmax()]
                print("average: {0:0.2f}".format(avg))
                print("most called: {}".format(most_called))
                plt.pause(0.1)
    print("1")
    plt.show()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Run a HTTP server")
    parser.add_argument("-l", "--listen", default="192.168.0.3", help="Specify the IP address on which the server listens")
    parser.add_argument("-p", "--port", type=int, default=8000, help="Specify the port on which the server listens")
    args = parser.parse_args()

    t = threading.Thread(target=visualization, args=(rf_db, ))
    t.setDaemon(False)
    t.start()

    # run server
    run(addr=args.listen, port=args.port)


