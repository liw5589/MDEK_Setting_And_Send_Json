import requests
import argparse
import numpy as np
import time

RF_ID = 123

if __name__ == '__main__':
    while True:
        parser = argparse.ArgumentParser(description="Run a HTTP client")
        parser.add_argument("-l", "--listen", default="192.168.0.3", help="Specify the IP address on which the server listens")
        parser.add_argument("-p", "--port", type=int, default=8000, help="Specify the port on which the server listens")
        args = parser.parse_args()

        distance = abs(np.around(np.random.normal(), 1))
        r = requests.get('http://{}:{}?id={}&d={:.5}'.format(args.listen, args.port, RF_ID, distance))

        print(r.content)

        time.sleep(.1)
