# Run server

    python3 server.py

# Run client

    python3 client.py

# Allow port

    sudo ufw allow 8000

# Update server ip

    localhost -> 192.168.0.3