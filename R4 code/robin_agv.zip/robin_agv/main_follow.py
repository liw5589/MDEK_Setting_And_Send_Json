import sys

sys.path.append('/usr/local/lib')

import rospy  # import order is important
from geometry_msgs.msg import Twist

import time
import numpy as np
import serial  # import order is important
import math
import threading
import os

# 1) read documentation https://www.decawave.com/mdek1001/usermanual/
# - check commands(for development)
# 2) connect with pc(supply power)
# - ls -l /dev/ttyACM*
# - sudo chmod a+rw /dev/ttyACM*
# 3) install app & do setting
# - install app from homepage
# - get anchor(1ae) & tag(3ae) id(set TAG_NAME)
# - set network(or create)
# - update rate(0.1hz -> 5hz) (depends on your state)
# - set Target(anchor) as INITIATOR & set position (0, 0, 0)
# 4) place tags in 90 degree with same interval(set D)


# Device is connected to 3 tags and tracks one anchor
# Place TAG1(0, 0), TAG2(1, 0) and TAG3(0, 1) at D intervals
# Set tags and anchor(initiator) in same network and adjust update rate using android application


# -------------------------------------------------------------
# Settings for RF
D = 0.45  # distance from the arm
TAG_NAME = ['83B3'.encode(), '0893'.encode(), '1D23'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
ANCHOR_NAME = '4101'.encode()  # ANCHOR Name
TAG_COUNT = len(TAG_NAME)  # count of TAG
DISTANCE_OF_TERMINATE = 0.7  # meter

X_COORD_M, Y_COORD_M, TAG3, FLAG_DISTANCE = 0, 0, 0, 0
# -------------------------------------------------------------


# -------------------------------------------------------------
# helper functions
def swap(ser, name):
    ser_tmp = ser[:]
    for i in range(len(name)):
        a = TAG_NAME.index(name[i])
        ser[a] = ser_tmp[i]
    return ser
# -------------------------------------------------------------


# -------------------------------------------------------------
# THIS IS MAGIC DON'T TOUCH
# Operating TAG
print('Setting TAG System..')

ACM = [None] * TAG_COUNT
ACM_ID = [None] * TAG_COUNT

for i in range(0, TAG_COUNT):
    ACM[i] = serial.Serial("/dev/ttyACM" + str(i), 115200, timeout=5)  # check additional usb connect (ls -l /dev/ttyACM*)

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].write('\r'.encode())

time.sleep(0.5)

for i in range(TAG_COUNT):
    ACM[i].write('\r'.encode())

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].flushInput()
    ACM[i].flushOutput()

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].write('si'.encode())  # get "system info"
    ACM[i].write('\n'.encode())

time.sleep(1)

for i in range(TAG_COUNT):
    for i in range(TAG_COUNT):
        ACM_ID[i] = ACM[i].readline()
        ACM_ID[i] = ACM_ID[i][53:57]  # pretty print "id"

ACM = swap(ACM, ACM_ID)  # Set Tag in appropriate Location

print('Complete TAG Init Serial Ports.')
# -------------------------------------------------------------

# -------------------------------------------------------------
# INIT for get distance
for i in range(TAG_COUNT):
    ACM[i].write('les'.encode())  # Get Distance(check document)
time.sleep(.3)

for i in range(TAG_COUNT):
    ACM[i].write('\n'.encode())
time.sleep(.3)

print('Completed TAG Setting!!')
# -------------------------------------------------------------

def shutdown():
    cmd_vel.publish(Twist())  # a default Twist has linear.x of 0 and angular.z of 0.  So it'll stop TurtleBot
    rospy.sleep(1)  # sleep just makes sure TurtleBot receives the stop command prior to shutting down the script


def cal_angle(x, y):
    if y > 0:
        return math.atan(x / y) * 180 / math.pi  # degree
    else:
        if x > 0:
            return 180 + math.atan(x / (y + sys.float_info.epsilon)) * 180 / math.pi  # degree
        else:
            return - 180 + math.atan(x / (y + sys.float_info.epsilon)) * 180 / math.pi  # degree


def rf_thread():
    global X_COORD_M, Y_COORD_M, TAG3, FLAG_DISTANCE

    def push(list_in, data):
        list_in[1:] = list_in[:-1]
        list_in[0] = data

    def filtering(data_list):
        data_list_copy = data_list[:]  # make copy data
        data_list_copy.sort()
        return np.mean(data_list_copy[1:-2])  # delete max, min value from 7 data and average

    tag_data = [None] * TAG_COUNT

    # TEMP TAG lists
    TAG1_list, TAG2_list, TAG3_list = [0] * 5, [0] * 5, [0] * 5
    while True:
        # get rf distance
        for i in range(TAG_COUNT):
            acm_data = ACM[i].readline()
            acm_data = acm_data.split(' '.encode())
            tag_data[i] = acm_data[0]

        # Read and change data from each tags
        for i in range(TAG_COUNT):
            acm_data = ACM[i].readline()
            acm_data = acm_data.split(' '.encode())
            tag_data[i] = acm_data[0]

        r_distance, FLAG_DISTANCE = [0.0, 0.0, 0.0], 0
        for i in range(TAG_COUNT):  # 1: TAG1, 2: TAG2, 3: TAG3
            if tag_data[i][0:4] == ANCHOR_NAME:
                FLAG_DISTANCE = 1
                r_distance[i] = float(tag_data[i].split('='.encode())[1])  # [Anchor name, distance]
            else:
                print("No distance data")
                FLAG_DISTANCE = 0

        # get rf distance
        if FLAG_DISTANCE == 1:
            TAG3 = r_distance[2]
            push(TAG1_list, r_distance[0])
            push(TAG2_list, r_distance[1])
            push(TAG3_list, r_distance[2])
            TAG1_filtered, TAG2_filtered, TAG3_filtered = filtering(TAG1_list), filtering(TAG2_list), filtering(TAG3_list)  # for smoothing

            X_COORD_M = ((TAG1_filtered ** 2) - (TAG2_filtered ** 2) + (D ** 2)) / (2 * D) - D
            Y_COORD_M = ((TAG1_filtered ** 2) - (TAG3_filtered ** 2) + (D ** 2)) / (2 * D) - D
# -------------------------------------------------------------


if __name__ == '__main__':
    try:
        rospy.init_node('GoForward', anonymous=False)  # initialize
        cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)  # Create a publisher which can "talk" to TurtleBot and tell it to move
        rospy.on_shutdown(shutdown)
    except Exception as e:
        rospy.loginfo('Unable to launch ROS, terminate ros\n{}'.format(e))
        exit()

    r = rospy.Rate(10)  # TurtleBot will stop if we don't keep telling it to move. How often should we tell it to move? 10 HZ
    move_cmd = Twist()  # Twist is a datatype for velocity

    time_moving = time.time()

    forward_velocity = 0

    t1 = threading.Thread(target=rf_thread)
    t1.start()

    time.sleep(1)

    # start logic
    while not rospy.is_shutdown():
        # get rf distance
        if FLAG_DISTANCE == 1:
            os.system('clear')
            angle = cal_angle(X_COORD_M, Y_COORD_M)
            dist_to_target = TAG3

            # print log
            print("----------------------------------------")
            print("X: {0:.2f}m Y: {1:.2f}m ANGLE: {2:.2f}°".format(X_COORD_M, Y_COORD_M, angle))
            print("Distance to target: {:.2f}m".format(dist_to_target))
            print("State: ", end='')

            # ------------------------------------
            # avoid obstacle and control

            # algorithm
            # 1) check distance with leader -> stop or go
            # 2) (far from leader) -> check direction
            #   - (right direction) -> go forward
            #   - (wrong direction) -> rotate

            # Exist of distance data

            # 1) check distance with leader -> stop
            if dist_to_target < DISTANCE_OF_TERMINATE:
                forward_velocity += -0.2
                if abs(angle) > 30:
                    print("Rotate")
                    move_cmd.angular.z = - angle / 180
                else:
                    print("Stop")
                    move_cmd.angular.z = 0
            elif dist_to_target > DISTANCE_OF_TERMINATE * 5:
                if abs(angle) > (dist_to_target * 30):
                    print("Rotate")
                    move_cmd.angular.z = - angle / 120
                else:
                    print("Forward")
                    forward_velocity += 0.5
                    move_cmd.angular.z = 0
            else:
                # 2) check direction
                if abs(angle) > (dist_to_target * 10):
                    print("Rotate")
                    move_cmd.angular.z = - angle / 120
                    if abs(angle) > 90:
                        forward_velocity -= 0.05
                else:
                    print("Forward")
                    forward_velocity += 0.3
                    move_cmd.angular.z = 0

        else:
            # exception handling for rf distance data error
            move_cmd.linear.x = 0
            move_cmd.angular.z = 0
            cmd_vel.publish(move_cmd)
            continue

        # update ros command
        if forward_velocity < 0:
            forward_velocity = 0
        elif forward_velocity > 4:
            forward_velocity = 4
        move_cmd.linear.x = forward_velocity * (0.2 / 4)
        print("Velocity: {:.2f} m/s".format(move_cmd.linear.x))
        print("Angular velocity: {:.2f} rad/s".format(move_cmd.angular.z))
        print("----------------------------------------")
        cmd_vel.publish(move_cmd)

        r.sleep()

    # [IMPORTANT] termiate rf
    for i in range(3):
        ACM[i].write('\r'.encode())
        ACM[i].write('quit'.encode())
        ACM[i].write('\n'.encode())
        ACM[i].close()

    time.sleep(.3)
    print('System down...')
