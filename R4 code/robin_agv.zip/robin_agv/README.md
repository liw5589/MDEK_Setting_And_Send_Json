# robin_agv

# Launch ROS

    roslaunch turtlebot_bringup minimal.launch

# Detect obstacles and avoid with rf & realsense camera

    python3 main.py

# Follow leader with rf

    python3 main_follow.py

# Measure distance, angle and depth from drag in video

    python3 measure_drag.py

# Visualization of rf & obstacles

    python3 camera_and_rf_visualization.py

# Save & Load data(rgb, depth)

    python3 tools/realsense_data_save.py
    python3 tools/realsense_data_load.py