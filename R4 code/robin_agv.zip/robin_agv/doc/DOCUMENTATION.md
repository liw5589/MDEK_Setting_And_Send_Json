# 작업리스트(nvidia nano)

    1. ubuntu 18.04 설치
    2. ros(melodic) 설치
    3. kobuki 드라이버 설치 및 ROS연동
    4. realsense 드라이버 설치
    5. torch 및 torchvision설치
    6. realsense기반 rgb 및 depth 추출
    7. 안정적인 depth추출을 위한 필터 적용
    8. depth기반 장애물 인식(50cm이내)
    9. 인식한 장애물 기반 이동 방향 도출(좌, 우)
    10. depth를 3d point cloud로 변환
    11. 3d point cloud를 depth scale을 활용해 실제 거리로 변환
    12. 3d point cloud기반 장애물 가로 길이 도출
    13. 3d point cloud기반 장애물 세로 길이 도출
    14. 3d point cloud기반 장애물 깊이 도출
    15. 3d point cloud기반 장애물 가로 각도 도출
    16. 인식한 장애물 정보(길이, 각도...) 기반 주행(방향도출 및 이동)
    17. 위치인식 통합


# Kobuki RF 하드웨어 설치

     ----- <전면> -----
    | 3번     (ANCHOR) |
    |      (nano)      |
    | 1번        2번    |
     ----- <후면> -----


# Kobuki 실행

    1. ANCHOR에 전원 인가(건전지)
    2. jetson nano 부팅, 각 TAG에 올바르게 전원이 들어오는지 확인
    3. (필요하다면) 어플을 통해 2개의 네트워크 내 각각 3개의 TAG와 1개의 ANCHOR가 작동하는지 확인
    4. nano와 PC를 같은 네트워크에 두고 ssh를 이용해 각각 접속
    5. ~/.bashrc 파일에서 master와 nano의 IP 설정
        export ROS_MASTER_URL=http://[PC IP]:11311
        export ROS_HOSTNAME=[nano IP]

        예시)
        export ROS_MASTER_URL=http://192.168.0.5:11311
        export ROS_HOSTNAME=192.168.0.7

    6. 설정을 완료한 뒤 ssh 재접속
    7. $ roslaunch turtlebot_bringup minimal.launch 로 nano와 kobuki간의 연결
        소리가 나면 올바른 접속이 된 것.
    8. 또다른 ssh 연결을 통해 터미널 OPEN
    9. $ ls -l /dev/ttyACM* 로 연결된 3개의 TAG 확인 (ttyACM0, ttyACM1, ttyACM2)
    10. $ sudo chmod a+rw /dev/ttyACM* 로 usb 접근 권한 설정
    11. python3 main_rf_with_obstacle.py (선행 목표물 추적)
        python3 follow_rf.py (후행 추종)

    12. swap 함수 에러가 나는 등 RF 연결 문제가 생길 시 USB 재연결 뒤 RF 불이 제대로 들어오는지 확인 후 단계 9번부터 다시 실행