# Install torch & torchvision (https://devtalk.nvidia.com/default/topic/1049071/jetson-nano/pytorch-for-jetson-nano/)

    wget https://nvidia.box.com/shared/static/mmu3xb3sp4o8qg9tji90kkxl1eijjfc6.whl -O torch-1.1.0-cp36-cp36m-linux_aarch64.whl
    sudo pip3 install numpy torch-1.1.0-cp36-cp36m-linux_aarch64.whl

    sudo apt-get install libjpeg-dev zlib1g-dev
    git clone -b v0.3.0 https://github.com/pytorch/vision torchvision
    cd torchvision
    sudo python3 setup.py install
    cd ../
    sudo rm -rf torchvision

# If there is numpy problem

    sudo apt-get remove --purge python3-numpy
    sudo pip3 install numpy

# Install ssh server

    sudo apt update
    sudo apt install openssh-server

    start ssh server
    sudo systemctl start ssh

    check server status
    sudo systemctl status ssh

    stop ssh server
    sudo systemctl stop ssh