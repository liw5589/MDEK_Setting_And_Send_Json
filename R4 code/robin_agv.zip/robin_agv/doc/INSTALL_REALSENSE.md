# Install Realsense(PC)

## Register the server's public key:

    sudo apt-key adv --keyserver keys.gnupg.net --recv-key F6E65AC044F831AC80A06380C8B3A55A6F3EFCDE || sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-key F6E65AC044F831AC80A06380C8B3A55A6F3EFCDE

## Add the server to the list of repositories:

    * Ubuntu 18 LTS
    sudo add-apt-repository "deb http://realsense-hw-public.s3.amazonaws.com/Debian/apt-repo bionic main" -u

    * Ubuntu 16 LTS:
    sudo add-apt-repository "deb http://realsense-hw-public.s3.amazonaws.com/Debian/apt-repo xenial main" -u

## Install the libraries

    sudo apt-get install librealsense2-dkms
    sudo apt-get install librealsense2-utils

    sudo apt-get update && apt-get upgrade
    sudo pip3 install pyrealsense2


# Install Realsense(AGX)

## Follow instruction below

    git clone https://github.com/jetsonhacks/buildLibrealsense2Xavier
    cd buildLibrealsense2Xavier

    gedit buildPatchedKernel.sh

    replace "32.1.0" -> "your version"

    ./buildPatchedKernel.sh

    update for release-build and python3

    gedit ./installLibrealsense.sh

    replace
    cmake ../ -DBUILD_EXAMPLES=true -DBUILD_WITH_CUDA=true
    to
    cmake ../ -DCMAKE_BUILD_TYPE=Release -DBUILD_EXAMPLES=true -DBUILD_WITH_CUDA=true -DBUILD_PYTHON_BINDINGS=bool:true -DPYTHON_EXECUTABLE=/usr/bin/python3

    Install dependencies

    sudo apt-get install python3-dev python3-tk
    sudo apt-get install git libssl-dev libusb-1.0-0-dev pkg-config libgtk-3-dev
    sudo apt-get install libglfw3-dev libgl1-mesa-dev libglu1-mesa-dev

    ./installLibrealsense.sh

    gedit ~/.bashrc

    Add export PYTHONPATH=$PYTHONPATH:/usr/local/lib

## Run realsense viewer

    realsense-viewer