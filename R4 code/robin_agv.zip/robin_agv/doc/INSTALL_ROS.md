# Install ROS for xavier(follow the instruction below)

    https://github.com/jetsonhacks/installROSXavier

# Create a workspace (if not present)

    source /opt/ros/melodic/setup.bash
    mkdir -p ~/catkin_ws/src
    cd ~/catkin_ws/src
    catkin_init_workspace

# Installation of Turtlebot2-related packages(follow https://github.com/gaunthan/Turtlebot2-On-Melodic/blob/master/install_basic.sh)

    cd ~/catkin_ws\

    mkdir -p src
    cd src

    git clone https://github.com/turtlebot/turtlebot.git
    git clone https://github.com/turtlebot/turtlebot_msgs.git
    git clone https://github.com/turtlebot/turtlebot_apps.git
    git clone https://github.com/turtlebot/turtlebot_simulator.git

    git clone https://github.com/yujinrobot/kobuki_msgs.git
    git clone https://github.com/yujinrobot/kobuki.git
    mv kobuki/kobuki_description kobuki/kobuki_node kobuki/kobuki_keyop kobuki/kobuki_safety_controller kobuki/kobuki_bumper2pc ./
    rm -rf kobuki

    git clone https://github.com/yujinrobot/yujin_ocs.git
    mv yujin_ocs/yocs_cmd_vel_mux yujin_ocs/yocs_controllers .
    rm -rf yujin_ocs

    sudo apt-get install ros-melodic-kobuki-* -y
    sudo apt-get install ros-melodic-ecl-streams -y
    cd ~/catkin_ws

# build opencv(xavier)

    https://www.jetsonhacks.com/2018/11/08/build-opencv-3-4-on-nvidia-jetson-agx-xavier-developer-kit/

# build opencv(nano)

    https://jkjung-avt.github.io/opencv-on-nano/

# Install extra package for catkin_make

    sudo apt-get install ros-melodic-image-geometry
    sudo apt-get install ros-melodic-depth-image-proc
    sudo apt-get install ros-melodic-joy
    sudo apt-get install ros-melodic-ecl

# Build with the following command

    catkin_make

# Set ROS_IP in ~/.bashrc <== NOT NEEDED

    to localhost or your ros ip

# Set udev(please connect kobuki before udev configuration)

    rosrun kobuki_ftdi create_udev_rules

# Run

    source ~/catkin_ws/devel/setup.bash
    roslaunch turtlebot_bringup minimal.launch

    source ~/catkin_ws/devel/setup.bash
    roslaunch turtlebot_teleop keyboard_teleop.launch

# Set bashrc

    gedit ~/.bashrc

    Add
    source /opt/ros/melodic/setup.bash
    source ~/catkin_ws/devel/setup.bash
    sudo chmod a+rw /dev/ttyACM*

# for python3

    sudo pip3 install rospkg
