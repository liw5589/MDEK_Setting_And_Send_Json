# NANO1
    TAG_NAME = ['D92E'.encode(), '5DAB'.encode(), 'C88C'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
    ANCHOR_NAME = '8B0D'.encode()  # ANCHOR Name

# NANO2
    TAG_NAME = ['83B3'.encode(), '0893'.encode(), '1D23'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
    ANCHOR_NAME = '4101'.encode()  # ANCHOR Name

# NANO3
    TAG_NAME = ['D20C'.encode(), '5A8C'.encode(), 'D802'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
    ANCHOR_NAME = 'D105'.encode()  # ANCHOR Name

# NANO4
    TAG_NAME = ['DCB5'.encode(), '5A27'.encode(), '8B39'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
    ANCHOR_NAME = '5610'.encode()  # ANCHOR Name