import math
import os
import sys
import time

import cv2
import numpy as np
import serial

# 1) read documentation https://www.decawave.com/mdek1001/usermanual/
# - check commands(for development)
# 2) connect with pc(supply power)
# 3) install app & do setting
# - install app from homepage
# - get anchor(1ae) & tag(3ae) id(set TAG_NAME)
# - set network
# - update rate(0.1hz -> 5hz) (depends on your state)
# 4) place tags in 90 degree with same interval(set D)


# Device is connected to 3 tags and tracks one anchor
# Place TAG1(0, 0), TAG2(1, 0) and TAG3(0, 1) at D intervals
# Set tags and anchor(initiator) in same network and adjust update rate using android application

D = 0.21  # distance from the arm
TAG_NAME = ['D92E'.encode(), '19B2'.encode(), 'C88C'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
TAG_COUNT = len(TAG_NAME)  # count of TAG
ANCHOR_NAME = '8B0D'.encode()  # ANCHOR Name


# swap Tag for Appropriate Tag Location (TAG1, TAG2, TAG3) -> (RA, RB, RC)
def swap(ser, name):
    ser_tmp = ser[:]
    for i in range(len(name)):
        a = TAG_NAME.index(name[i])
        ser[a] = ser_tmp[i]
    return ser


# -------------------------------------------------------------------
# THIS IS MAGIC DON'T TOUCH
# Operating TAG
print('Setting TAG System..')

ACM = [None] * TAG_COUNT
ACM_ID = [None] * TAG_COUNT

for i in range(0, TAG_COUNT):
    ACM[i] = serial.Serial("/dev/ttyACM" + str(i), 115200, timeout=5)  # check additional usb connect (ls -l /dev/ttyACM*)

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].write('\r'.encode())

time.sleep(0.5)

for i in range(TAG_COUNT):
    ACM[i].write('\r'.encode())

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].flushInput()
    ACM[i].flushOutput()

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].write('si'.encode())  # get "system info"
    ACM[i].write('\n'.encode())

time.sleep(1)

for i in range(TAG_COUNT):
    for i in range(TAG_COUNT):
        ACM_ID[i] = ACM[i].readline()
        ACM_ID[i] = ACM_ID[i][53:57]  # pretty print "id"

ACM = swap(ACM, ACM_ID)  # Set Tag in appropriate Location

print('Complete Init Serial Ports.')
# -------------------------------------------------------------------

for i in range(TAG_COUNT):
    ACM[i].write('les'.encode())  # Get Distance(check document)
time.sleep(.3)

for i in range(TAG_COUNT):
    ACM[i].write('\n'.encode())
time.sleep(.3)

print('Completed Setting!!')


def push(list_in, data):
    list_in[1:] = list_in[:-1]
    list_in[0] = data


def cal_angle(x, y):
    if y > 0:
        return math.atan(x / y) * 180 / math.pi  # degree
    else:
        if x > 0:
            return 180 + math.atan(x / (y + sys.float_info.epsilon)) * 180 / math.pi  # degree
        else:
            return - 180 + math.atan(x / (y + sys.float_info.epsilon)) * 180 / math.pi  # degree


def filtering(data_list):
    data_list_copy = data_list[:]
    data_list_copy.sort()

    return np.mean(data_list_copy[1:-2])


if __name__ == '__main__':
    FLAG_DISTANCE = 0  # Flag of sensing distance

    RA_list = [0] * 7
    RB_list = [0] * 7
    RC_list = [0] * 7

    while True:
        try:
            cv2.namedWindow('MAP', cv2.WINDOW_AUTOSIZE)
            key = cv2.waitKey(1)
            map_image = np.zeros([200, 200, 3])

            # Green dot in map (center point)
            cv2.line(map_image, (100, 0), (100, 200), (0, 100, 0), 1)
            cv2.line(map_image, (0, 100), (200, 100), (0, 100, 0), 1)
            cv2.line(map_image, (100, 100), (100, 100), (0, 255, 0), 5)

            # Set anchor x, y coord
            x_coord = 0
            y_coord = 0
            tag_data = [None] * TAG_COUNT
            RA, RA_mean, RB, RB_mean, TAG3, RC_mean = 0, 0, 0, 0, 0, 0

            # Read and change data from each tags
            for i in range(TAG_COUNT):
                acm_data = ACM[i].readline()
                acm_data = acm_data.split(' '.encode())
                tag_data[i] = acm_data[0]

            # Measure distance between ANCHOR and TAGS
            os.system('clear')
            r_distance = [0.0, 0.0, 0.0]
            for i in range(TAG_COUNT):  # 1: TAG1, 2: TAG2, 3: TAG3
                if tag_data[i][0:4] == ANCHOR_NAME:
                    FLAG_DISTANCE = 1
                    r_distance[i] = float(tag_data[i].split('='.encode())[1])  # [Anchor name, distance]
                else:
                    FLAG_DISTANCE = 0
                    print("No distance data")

            if FLAG_DISTANCE == 1:
                RA = r_distance[0]
                RB = r_distance[1]
                TAG3 = r_distance[2]

                push(RA_list, r_distance[0])
                push(RB_list, r_distance[1])
                push(RC_list, r_distance[2])

                RA_mean = np.mean(RA_list)
                RB_mean = np.mean(RB_list)
                RC_mean = np.mean(RC_list)

                RA_filtered = filtering(RA_list)
                RB_filtered = filtering(RB_list)
                RC_filtered = filtering(RC_list)

                # Calculate x, y coord
                x_coord = ((RA ** 2) - (RB ** 2) + (D ** 2)) / (2 * D) - D / 2
                x_coord = round(x_coord, 2)
                y_coord = ((RA ** 2) - (TAG3 ** 2) + (D ** 2)) / (2 * D) - D / 2
                y_coord = round(y_coord, 2)

                x_coord_m = ((RA_mean ** 2) - (RB_mean ** 2) + (D ** 2)) / (2 * D) - D / 2
                x_coord_m = round(x_coord_m, 2)
                y_coord_m = ((RA_mean ** 2) - (RC_mean ** 2) + (D ** 2)) / (2 * D) - D / 2
                y_coord_m = round(y_coord_m, 2)

                x_coord_f = ((RA_filtered ** 2) - (RB_filtered ** 2) + (D ** 2)) / (2 * D) - D / 2
                x_coord_f = round(x_coord_f, 2)
                y_coord_f = ((RA_filtered ** 2) - (RC_filtered ** 2) + (D ** 2)) / (2 * D) - D / 2
                y_coord_f = round(y_coord_f, 2)

                # Mapping x, y coord
                x_map = int((x_coord + 10) * 10)
                y_map = int((- y_coord + 10) * 10)

                x_map_m = int((x_coord_m + 10) * 10)
                y_map_m = int((- y_coord_m + 10) * 10)

                x_map_f = int((x_coord_f + 10) * 10)
                y_map_f = int((- y_coord_f + 10) * 10)

                print("========ANCHOR: %s========" % ANCHOR_NAME)
                print("RA: %.2f RB: %.2f RC: %.2f" % (RA, RB, TAG3))
                print("RA_mean: %.2f RB_mean: %.2f RC_mean: %.2f" % (RA_mean, RB_mean, RC_mean))
                print("X: %.2f Y: %.2f" % (x_coord, y_coord))
                print("avg X: %.2f avg Y: %.2f" % (x_coord_m, y_coord_m))
                print("Angle: %.2f" % cal_angle(x_coord_m, y_coord_m))
                print("! Please press 'q' to close window and turn off RF correctly")

                # Red dot in map (current x, y coord)
                cv2.line(map_image, (100, 100), (x_map, y_map), (0, 0, 255), 1)
                cv2.line(map_image, (x_map, y_map), (x_map, y_map), (0, 0, 255), 5)

                # Purple dot in map (average x, y coord)
                cv2.line(map_image, (100, 100), (x_map_m, y_map_m), (255, 0, 255), 1)
                cv2.line(map_image, (x_map_m, y_map_m), (x_map_m, y_map_m), (255, 0, 255), 5)

                # Blue dot in map (average x, y coord)
                cv2.line(map_image, (100, 100), (x_map_f, y_map_f), (255, 0, 0), 1)
                cv2.line(map_image, (x_map_f, y_map_f), (x_map_f, y_map_f), (255, 0, 0), 5)

            if key & 0xFF == ord('q') or key == 27:
                cv2.destroyAllWindows()
                break

            cv2.imshow('MAP', map_image)
        except Exception as e:
            print(e)

    # -------------------------------------------------------------------
    # THIS IS MAGIC DON'T TOUCH
    # terminate rf signal
    for i in range(3):
        ACM[i].write('\r'.encode())
        ACM[i].write('quit'.encode())
        ACM[i].write('\n'.encode())
        ACM[i].close()

    time.sleep(.3)
    print('System down...')
    # -------------------------------------------------------------------
