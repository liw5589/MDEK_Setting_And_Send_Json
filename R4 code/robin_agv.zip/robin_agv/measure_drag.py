import math
import os

import cv2
import numpy as np
import pyrealsense2 as rs


def calculate_distance(list1, list2):  # Take two 3D points and calculate distance
    dist = math.sqrt((list1[0] - list2[0]) ** 2 + (list1[1] - list2[1]) ** 2 + (list1[2] - list2[2]) ** 2)
    return dist  # in meter


def click_and_crop(event, x, y, flags, param):  # Make two point from drag
    # Global variation
    global REF_PT, DRAG

    # write x, y and set flag
    if event == cv2.EVENT_LBUTTONDOWN:
        REF_PT = [(x, y)]
        DRAG = True

    elif event == cv2.EVENT_LBUTTONUP:
        REF_PT.append((x, y))
        DRAG = False


def cal_angle(height, hypotenuse):
    return math.asin(height / hypotenuse) * 180 / math.pi  # degree


def pixel_to_3d(pixel_x, pixel_y, depth_image, depth_intrinsics):  # Convert pixel (x, y), depth to (x, y, z) coord
    coord = [pixel_y, pixel_x]
    z, x, y = rs.rs2_deproject_pixel_to_point(depth_intrinsics, coord, depth_image[pixel_y][pixel_x] * depth_scale)
    z = -z
    return [x, y, z]


if __name__ == '__main__':
    # Start pipeline
    pipeline = rs.pipeline()

    config = rs.config()
    config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
    config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

    profile = pipeline.start(config)

    profile = pipeline.get_active_profile()
    depth_profile = rs.video_stream_profile(profile.get_stream(rs.stream.depth))

    # Waiting frames for preparation
    for x in range(5):
        pipeline.wait_for_frames()

    # Take depth scale to get real distance
    depth_sensor = profile.get_device().first_depth_sensor()
    depth_scale = depth_sensor.get_depth_scale()
    print("Depth Scale is: ", depth_scale)

    # Depth Filter
    spatial = rs.spatial_filter()
    spatial.set_option(rs.option.holes_fill, 3)
    hole_filling = rs.hole_filling_filter()
    depth_to_disparity = rs.disparity_transform(True)
    disparity_to_depth = rs.disparity_transform(False)

    # Create an align object
    align_to = rs.stream.color
    align = rs.align(align_to)

    # Click event
    REF_PT = []
    DRAG = True

    try:
        while True:
            frames = pipeline.wait_for_frames()  # Get frames

            aligned_frames = align.process(frames)

            # Filtering depth frame
            depth_frame = aligned_frames.get_depth_frame()
            depth_frame = depth_to_disparity.process(depth_frame)
            depth_frame = spatial.process(depth_frame)
            depth_frame = disparity_to_depth.process(depth_frame)
            depth_frame = hole_filling.process(depth_frame)
            color_frame = aligned_frames.get_color_frame()

            depth_intrinsics = rs.video_stream_profile(depth_frame.profile).get_intrinsics()

            # Validate that both frames are valid
            if not depth_frame or not color_frame:
                continue

            # Get depth, color numpy data
            depth_image = np.asanyarray(depth_frame.get_data())
            color_image = np.asanyarray(color_frame.get_data())

            # Open window and set mouse call back
            cv2.namedWindow('Measure', cv2.WINDOW_AUTOSIZE)
            cv2.setMouseCallback('Measure', click_and_crop)

            key = cv2.waitKey(1)

            # Press esc or 'q' to close the image window
            if key & 0xFF == ord('q') or key == 27:
                cv2.destroyAllWindows()
                break

            # Drag in image to measure distance
            if not DRAG:
                # Set point from drag
                point1_3d = pixel_to_3d(REF_PT[0][0], REF_PT[0][1], depth_image, depth_intrinsics)
                point2_3d = pixel_to_3d(REF_PT[1][0], REF_PT[1][1], depth_image, depth_intrinsics)

                # Get depth distance from point
                point1_depth = depth_image[REF_PT[0][1]][REF_PT[0][0]] * depth_scale
                point2_depth = depth_image[REF_PT[1][1]][REF_PT[1][0]] * depth_scale

                os.system('clear')
                print("Distance: ", np.around(calculate_distance(point1_3d, point2_3d), 2))
                print("Angle: ", np.around(cal_angle(point1_depth - point2_depth, calculate_distance(point1_3d, point2_3d)), 2))

                # Show mouse drag
                cv2.line(color_image, REF_PT[0], REF_PT[1], 255, 2)
                point1_3d_text = str(np.around(point1_3d, 2))
                point2_3d_text = str(np.around(point2_3d, 2))
                cv2.putText(color_image, point1_3d_text, (REF_PT[0][0], REF_PT[0][1]), cv2.FONT_HERSHEY_SCRIPT_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(color_image, point2_3d_text, (REF_PT[1][0], REF_PT[1][1]), cv2.FONT_HERSHEY_SCRIPT_SIMPLEX, 0.5, (255, 255, 255), 1)

            # Image showing
            cv2.imshow('Measure', color_image)

    finally:
        pipeline.stop()
