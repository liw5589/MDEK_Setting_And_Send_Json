import sys

sys.path.append('/usr/local/lib')

import pyrealsense2 as rs

import rospy  # import order is important
from geometry_msgs.msg import Twist

import time
import cv2
import numpy as np
import serial  # import order is important
import math
import threading
import os

# 1) read documentation https://www.decawave.com/mdek1001/usermanual/
# - check commands(for development)
# 2) connect with pc(supply power)
# - ls -l /dev/ttyACM*
# - sudo chmod a+rw /dev/ttyACM*
# 3) install app & do setting
# - install app from homepage
# - get anchor(1ae) & tag(3ae) id(set TAG_NAME)
# - set network(or create)
# - update rate(0.1hz -> 5hz) (depends on your state)
# - set Target(anchor) as INITIATOR & set position (0, 0, 0)
# 4) place tags in 90 degree with same interval(set D)


# Device is connected to 3 tags and tracks one anchor
# Place TAG1(0, 0), TAG2(1, 0) and TAG3(0, 1) at D intervals
# Set tags and anchor(initiator) in same network and adjust update rate using android application


# -------------------------------------------------------------
# Settings for RF
D = 0.45  # distance from the arm
TAG_NAME = ['D92E'.encode(), '5DAB'.encode(), 'C88C'.encode()]  # TAG Names (TAG1, TAG2, TAG3)
ANCHOR_NAME = '8B0D'.encode()  # ANCHOR Name
TAG_COUNT = len(TAG_NAME)  # count of TAG
DISTANCE_OF_TERMINATE = 1.0  # meter

CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480

angle_prev = 90
X_COORD_M, Y_COORD_M, TAG3 = 0, 0, 0

# Depth image filter
spatial = rs.spatial_filter()
spatial.set_option(rs.option.holes_fill, 3)
hole_filling = rs.hole_filling_filter()
depth_to_disparity = rs.disparity_transform(True)
disparity_to_depth = rs.disparity_transform(False)
# -------------------------------------------------------------

# -------------------------------------------------------------
# helper functions
def swap(ser, name):
    ser_tmp = ser[:]
    for i in range(len(name)):
        a = TAG_NAME.index(name[i])
        ser[a] = ser_tmp[i]
    return ser
# -------------------------------------------------------------


# -------------------------------------------------------------
# THIS IS MAGIC DON'T TOUCH
# Operating TAG
print('Setting TAG System..')

ACM = [None] * TAG_COUNT
ACM_ID = [None] * TAG_COUNT

for i in range(0, TAG_COUNT):
    ACM[i] = serial.Serial("/dev/ttyACM" + str(i), 115200, timeout=5)  # check additional usb connect (ls -l /dev/ttyACM*)

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].write('\r'.encode())

time.sleep(0.5)

for i in range(TAG_COUNT):
    ACM[i].write('\r'.encode())

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].flushInput()
    ACM[i].flushOutput()

time.sleep(1)

for i in range(TAG_COUNT):
    ACM[i].write('si'.encode())  # get "system info"
    ACM[i].write('\n'.encode())

time.sleep(1)

for i in range(TAG_COUNT):
    for i in range(TAG_COUNT):
        ACM_ID[i] = ACM[i].readline()
        ACM_ID[i] = ACM_ID[i][53:57]  # pretty print "id"

ACM = swap(ACM, ACM_ID)  # Set Tag in appropriate Location

print('Complete TAG Init Serial Ports.')
# -------------------------------------------------------------

# -------------------------------------------------------------
# INIT for get distance
for i in range(TAG_COUNT):
    ACM[i].write('les'.encode())  # Get Distance(check document)
time.sleep(.3)

for i in range(TAG_COUNT):
    ACM[i].write('\n'.encode())
time.sleep(.3)

print('Completed TAG Setting!!')
# -------------------------------------------------------------

def shutdown():
    cmd_vel.publish(Twist())  # a default Twist has linear.x of 0 and angular.z of 0.  So it'll stop TurtleBot
    rospy.sleep(1)  # sleep just makes sure TurtleBot receives the stop command prior to shutting down the script


def cal_angle(x, y):
    if y > 0:
        return math.atan(x / y) * 180 / math.pi  # degree
    else:
        if x > 0:
            return 180 + math.atan(x / (y + sys.float_info.epsilon)) * 180 / math.pi  # degree
        else:
            return - 180 + math.atan(x / (y + sys.float_info.epsilon)) * 180 / math.pi  # degree


def disparity():
    def func(x, a, b):
        return a * x ** 2 + b  # Quadratic function

    h, w = CAMERA_HEIGHT // 2, CAMERA_WIDTH
    result_image = np.zeros((h, w, 3)).astype('uint8')

    # from scipy.optimize import curve_fit
    #
    # def func(x, a, b):
    #     return a * x ** 2 + b
    #
    # x = np.array([None, None, None, None])
    # y = np.array([0, 40, 80, 120])
    #
    # for i in range(4):
    #     distance_list = [0] * 256
    #     for j in range(w):
    #         distance_list[int(data[CAMERA_HEIGHT//2 -1 - i * 40, j])] += 1  # data <- depth data
    #         x[i] = distance_list.index(max(distance_list))
    #
    # fit_log = curve_fit(func, y, x)[0]

    fit_log = [2.16836735e-04, 3.78571428e+00]  # calculated result of above equations

    for i in range(h):
        result_image[CAMERA_HEIGHT // 2 - 1 - i] = int(func(i, fit_log[0], fit_log[1]))

    return result_image


def depth_filter(depth_data):
    depth_data = depth_to_disparity.process(depth_data)
    depth_data = spatial.process(depth_data)
    depth_data = disparity_to_depth.process(depth_data)
    depth_data = hole_filling.process(depth_data)
    return depth_data


def pixel_to_3d(pixel_x, pixel_y, depth_image, depth_intrinsics):  # Convert pixel (x, y), depth to (x, y, z) coord
    coord = [pixel_y, pixel_x]
    z, x, y = rs.rs2_deproject_pixel_to_point(depth_intrinsics, coord, depth_image[pixel_y][pixel_x] * depth_scale)
    z = -z
    return [x, y, z]


def calculate_distance(list1, list2):  # Take two 2D points and calculate distance
    dist = float(math.sqrt((list1[0] - list2[0]) ** 2 + (list1[1] - list2[1]) ** 2))
    return dist  # in meter


def rotate(angle):
    # Converting from angles to radians
    relative_angle = abs(angle * math.pi / 180)  # convert degrees to radians

    move_cmd.linear.x = 0.0  # Stop moving forward
    cmd_vel.publish(move_cmd)

    print("Called rotate {}".format(angle))

    # Setting the current angle for calculate
    current_angle = 0

    # angular acceleration for smooth movements
    angular_acceleration = 0.0025

    # 1) rotate to ahead goal
    while current_angle < relative_angle:
        t0 = rospy.Time.now().to_sec()
        if abs(move_cmd.angular.z) < 0.6:  # maximum angle velocity
            if angle > 0:
                move_cmd.angular.z += -angular_acceleration  # accelerate angle velocity
            else:
                move_cmd.angular.z += angular_acceleration  # accelerate angle velocity
        else:
            if angle > 0:
                move_cmd.angular.z = -0.6  # maximum angle velocity
            else:
                move_cmd.angular.z = 0.6  # maximum angle velocity
        cmd_vel.publish(move_cmd)
        time.sleep(0.01)
        t1 = rospy.Time.now().to_sec()
        current_angle += abs(move_cmd.angular.z) * (t1 - t0)

    # 2) rotate more for smooth movement
    while abs(move_cmd.angular.z) > angular_acceleration:  # slow down
        if angle > 0:
            move_cmd.angular.z += angular_acceleration
        else:
            move_cmd.angular.z += -angular_acceleration
        cmd_vel.publish(move_cmd)
        time.sleep(0.01)

    # Forcing our robot to stop
    move_cmd.linear.x = 0
    move_cmd.angular.z = 0
    cmd_vel.publish(move_cmd)


def go_forward(meter):
    move_cmd.angular.z = 0  # Stop rotating
    cmd_vel.publish(move_cmd)

    print("Called go forward {}".format(meter))

    # Setting the current distance for calculate
    current_distance = 0

    # acceleration for smooth movements
    acceleration = 0.001

    # 1) move forward with smooth movement
    while current_distance < meter:
        t0 = rospy.Time.now().to_sec()
        if move_cmd.linear.x < 0.2:  # maximum velocity
            move_cmd.linear.x += acceleration  # accelerate velocity
        else:
            move_cmd.linear.x = 0.2  # maximum velocity
        cmd_vel.publish(move_cmd)
        time.sleep(0.01)
        t1 = rospy.Time.now().to_sec()
        current_distance += move_cmd.linear.x * (t1 - t0)

    # 2) move more for smooth movement
    while move_cmd.linear.x > 0:  # slow down
        move_cmd.linear.x -= acceleration
        cmd_vel.publish(move_cmd)
        time.sleep(0.01)

    # Forcing our robot to stop
    move_cmd.linear.x = 0
    move_cmd.angular.z = 0
    cmd_vel.publish(move_cmd)


def rf_thread():
    global X_COORD_M, Y_COORD_M, TAG3

    def push(list_in, data):
        list_in[1:] = list_in[:-1]
        list_in[0] = data

    def filtering(data_list):
        data_list_copy = data_list[:]  # make copy data
        data_list_copy.sort()
        return np.mean(data_list_copy[1:-2])  # delete max, min value from 7 data and average

    tag_data = [None] * TAG_COUNT

    # TEMP TAG lists
    TAG1_list, TAG2_list, TAG3_list = [0] * 5, [0] * 5, [0] * 5
    while True:
        # get rf distance
        for i in range(TAG_COUNT):
            acm_data = ACM[i].readline()
            acm_data = acm_data.split(' '.encode())
            tag_data[i] = acm_data[0]

        # Read and change data from each tags
        for i in range(TAG_COUNT):
            acm_data = ACM[i].readline()
            acm_data = acm_data.split(' '.encode())
            tag_data[i] = acm_data[0]

        r_distance, FLAG_DISTANCE = [0.0, 0.0, 0.0], 0
        for i in range(TAG_COUNT):  # 1: TAG1, 2: TAG2, 3: TAG3
            if tag_data[i][0:4] == ANCHOR_NAME:
                FLAG_DISTANCE = 1
                r_distance[i] = float(tag_data[i].split('='.encode())[1])  # [Anchor name, distance]
            else:
                print("No distance data")
                FLAG_DISTANCE = 0

        # get rf distance
        if FLAG_DISTANCE == 1:
            TAG3 = r_distance[2]
            push(TAG1_list, r_distance[0])
            push(TAG2_list, r_distance[1])
            push(TAG3_list, r_distance[2])
            TAG1_filtered, TAG2_filtered, TAG3_filtered = filtering(TAG1_list), filtering(TAG2_list), filtering(TAG3_list)  # for smoothing

            X_COORD_M = ((TAG1_filtered ** 2) - (TAG2_filtered ** 2) + (D ** 2)) / (2 * D) - D / 2
            Y_COORD_M = ((TAG1_filtered ** 2) - (TAG3_filtered ** 2) + (D ** 2)) / (2 * D) - D / 2


if __name__ == '__main__':
    # Init realsense
    pipeline = rs.pipeline()  # create pipeline
    config = rs.config()  # create realsense configuration
    config.enable_stream(rs.stream.depth, CAMERA_WIDTH, CAMERA_HEIGHT, rs.format.z16, 30)  # set resolution and depth type
    config.enable_stream(rs.stream.color, CAMERA_WIDTH, CAMERA_HEIGHT, rs.format.bgr8, 30)

    profile = pipeline.start(config)  # start pipeline
    for x in range(5):
        pipeline.wait_for_frames()  # skip 5 frames(skip error & depth_sensor improvement)

    profile = pipeline.get_active_profile()
    depth_profile = rs.video_stream_profile(profile.get_stream(rs.stream.depth))

    depth_sensor = profile.get_device().first_depth_sensor()  # (after 5 frame skip) get depth sensor
    depth_scale = depth_sensor.get_depth_scale()

    try:
        rospy.init_node('GoForward', anonymous=False)  # initialize
        cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)  # Create a publisher which can "talk" to TurtleBot and tell it to move
        rospy.on_shutdown(shutdown)
    except Exception as e:
        rospy.loginfo('Unable to launch ROS, terminate ros\n{}'.format(e))
        exit()

    r = rospy.Rate(10)  # TurtleBot will stop if we don't keep telling it to move. How often should we tell it to move? 10 HZ
    move_cmd = Twist()  # Twist is a datatype for velocity

    align_to = rs.stream.color
    align = rs.align(align_to)

    disparity_map = disparity()

    time_moving = time.time()

    STATE = 0
    # 0: finding RF / 1: heading to goal / 2: detecting medium goal / 3: reaching medium goal / 4: GOAL

    t = threading.Thread(target=rf_thread)
    t.start()

    time.sleep(1)

    # start logic
    while not rospy.is_shutdown():
        os.system('clear')

        time_current = time.time()

        # -------------------------------------------------------------
        # 1) Get camera data
        # Get frames
        frames = pipeline.wait_for_frames()
        aligned_frames = align.process(frames)

        depth_frame = aligned_frames.get_depth_frame()
        depth_frame = depth_filter(depth_frame)

        depth_intrinsics = rs.video_stream_profile(depth_frame.profile).get_intrinsics()

        # Validate that both frames are valid
        if not depth_frame:
            continue

        depth_image = np.asanyarray(depth_frame.get_data())[CAMERA_HEIGHT // 2:, :]

        depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.005), cv2.COLORMAP_BONE)[:, :, 0]  # TODO:
        depth_colormap = np.dstack((depth_colormap, depth_colormap, depth_colormap))

        angle = cal_angle(X_COORD_M, Y_COORD_M)
        dist_to_target = TAG3

        # print log
        print("X: {0:.2f}m Y: {1:.2f}m ANGLE: {2:.2f}°".format(X_COORD_M, Y_COORD_M, angle))
        print("Distance to target: {:.2f}m".format(dist_to_target))

        # when reach the obstacle
        if dist_to_target < DISTANCE_OF_TERMINATE:
            print("GOAL!")
            move_cmd.linear.x = 0
            if abs(angle) > 10:
                move_cmd.angular.z = - angle / 140
            else:
                move_cmd.angular.z = 0
            cmd_vel.publish(move_cmd)  # publish command
            STATE = 4
            continue

        if STATE == 1:  # 1: heading to goal
            move_cmd.linear.x = 0
            if abs(angle) > 22.5 or abs(angle_prev) > 22.5:
                move_cmd.angular.z = - angle / 180
            else:
                move_cmd.angular.z = 0
                STATE = 2
            cmd_vel.publish(move_cmd)  # publish command

        elif STATE == 2:  # 2: detecting medium goal
            # 1) remove floor
            floor_removed = np.where((depth_colormap - disparity_map == 255) | (depth_colormap - disparity_map < 50) | (depth_colormap <= 0), 0, 255).astype('uint8')

            if (floor_removed == 255).any():
                gray = cv2.cvtColor(floor_removed, cv2.COLOR_RGB2GRAY)  # TODO:
                threshold = cv2.threshold(gray, 1, 255, 0)[1]

                # 2) detect obstacles
                contours = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)[1]

                # 3) calculate medium goal
                medium_points = np.empty(shape=[0, 3])
                for cnt in contours:
                    x, y, w, h = cv2.boundingRect(cnt)  # find obstacle in camera view point
                    if h > 50:  # bigger than
                        # convert camera view point obstacle (x, y) to bird view (x, y) coordinate
                        points = np.empty(shape=[0, 2])
                        for i in range(w // 10):
                            for j in range(h // 20):
                                point = pixel_to_3d(x + 10 * i, y + 20 * j, depth_image, depth_intrinsics)[0:2]
                                if calculate_distance(point, [0, 0]) < 2:
                                    point[0] -= 0.1
                                    point[1] += 0.1
                                    if (abs(point[0] - X_COORD_M) > 0.5) and (abs(point[1] - Y_COORD_M) > 0.5):
                                        points = np.append(points, [point], 0)

                        # calculate medium points
                        if points.any():
                            if (abs(points[:, 0]) < 0.4).any():
                                if np.mean(points, 0)[0] > 0:
                                    print("obs in right")
                                    medium_point = np.min(points, 0)
                                    medium_point[0] -= 0.65
                                else:
                                    print("obs in left")
                                    medium_point = np.max(points, 0)
                                    medium_point[0] += 0.65
                                medium_point = np.append(medium_point, calculate_distance([0, 0], medium_point))
                                medium_points = np.append(medium_points, [medium_point], 0)

                # set medium goal(calculate with closest obstacle)
                if medium_points.any():
                    medium_goal = medium_points[np.argmin(medium_points[:, 2])][:2]
                    STATE = 3
                else:
                    print("No Obstacle, Go forward")
                    go_forward(0.8)
                    STATE = 1
            else:
                print("No Obstacle, Go forward")
                go_forward(0.8)
                STATE = 1

        elif STATE == 3:  # 3: reaching medium goal
            # get angle & distance
            medium_angle = cal_angle(medium_goal[0], medium_goal[1])
            medium_dist = calculate_distance([0, 0], medium_goal)

            # rotate -> forward -> rotate -> sleep
            rotate(medium_angle)
            go_forward(medium_dist)
            rotate(-medium_angle)
            go_forward(0.5)
            time.sleep(0.5)  # sleep for rf update

            # finetune angle again
            angle = cal_angle(X_COORD_M, Y_COORD_M)
            rotate(angle)
            time.sleep(1)

            STATE = 1
        else:
            if dist_to_target > DISTANCE_OF_TERMINATE:
                STATE = 1

        angle_prev = angle
        print(STATE)

        r.sleep()

        print('--------------------------------')

    # [IMPORTANT] terminate rf
    for i in range(3):
        ACM[i].write('\r'.encode())
        ACM[i].write('quit'.encode())
        ACM[i].write('\n'.encode())
        ACM[i].close()

    time.sleep(.3)
    print('System down...')
